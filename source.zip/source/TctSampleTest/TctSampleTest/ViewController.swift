//
//  ViewController.swift
//  TctSampleTest
//
//  Created by EMS on 2022/03/30.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

