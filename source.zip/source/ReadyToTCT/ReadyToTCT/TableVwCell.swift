//
//  TableVwCell.swift
//  ReadyToTCT
//
//  Created by EMS on 2022/05/22.
//

import Foundation
import UIKit

class TableVwCell: UITableViewCell {
    
    @IBOutlet weak var SingerLB: UILabel!
    @IBOutlet weak var titleLB: UILabel!
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var idLB: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}
