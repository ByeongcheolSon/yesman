//
//  ViewController.swift
//  ReadyToTCT
//
//  Created by EMS on 2022/05/22.
//

import UIKit

// API 부를때 해외로 할껀지 국내로 할껀지, 대입을 위한 이넘
enum ChartType:String {
    case Domestic = "domestic"
    case Overseas = "overseas"
    var code:String { rawValue }
}

// API 호출로 받아올 차트 리스트 내의 차트 객체
struct Chart {
    var id, rank:Int
    var title, singer, imageUrl:String

    var imgName:String {
        guard imageUrl.contains(".") else { return imageUrl }
        return imageUrl.components(separatedBy: ".")[0]
    }
    
    // map 함수를 쓸라고, 차트 객체 생성시 API 호출로 받아온 Json 데이터 파싱 해주는 부분
    init(_ dic:[String:Any]) {
        
        rank = dic["rank"] as? Int ?? 0
        imageUrl = dic["imageUrl"] as? String ?? ""
        title = dic["title"] as? String ?? ""
        singer = dic["singer"] as? String ?? ""
        id = dic["id"] as? Int ?? 0
        
    }
}

class ViewController: UIViewController {
    
    // 키보드를 보이고 안보이고를 해주는 객체
    var keyoardDismiss : UITapGestureRecognizer = UITapGestureRecognizer(target: ViewController.self, action: nil)
    
    // 차트 선택시 어떤거 선택 했는지 구분, 초기는 "국내" 로
    var selectType:ChartType = .Domestic
    
    @IBOutlet weak var SecBtn: UISegmentedControl!
    
    // 국내 <-> 해외 변경 생길 시 이벤트 받아주는 부분
    @IBAction func SegBTN(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            fetchCarList(.Domestic)
            selectType = .Domestic
        default:
            fetchCarList(.Overseas)
            selectType = .Overseas
        }
    }
    
    // "초기화" 버튼 눌렀을때 동작하는 부분
    @IBAction func RefreshBtn(_ sender: Any) {
        fetchCarList(selectType)
    }
    
    // "검색" 하기 위해 생성된 놈
    @IBOutlet weak var SearchBar: UISearchBar!
    
    // "오름차순" 버튼 눌렀을때 동작 하는 부분
    @IBAction func AESBtnAction(_ sender: Any) {
        
        // 우리가 전역 변수로 사용하는 차트 리스트의 값을 id 기준으로 오름차순으로 정렬한다.
        
        // 차트 리스트에 아직 파싱되지 않은 json 데이터가 들어가 있을 시
        let AES01 = self.chartList.sorted{ ($0["id"] as? Int ?? 0) < ($1["id"] as? Int ?? 0) }
        
        
        // 차트 리스트에 이미 오브젝트로 잘 들어가 있을 시
        let AES02 = self.CharLitstwithVO.sorted{ $0.id < $1.id }
        
        self.chartList = AES01
    }
    
    // "내림차순" 버튼 눌렀을때 동작 하는 부분
    @IBAction func DESCBtnAction(_ sender: Any) {
        
        // 차트 리스트에 아직 파싱되지 않은 json 데이터가 들어가 있을 시
        let DESC01 = self.chartList.sorted{ ($0["id"] as? Int ?? 0) > ($1["id"] as? Int ?? 0) }
        
        
        // 차트 리스트에 이미 오브젝트로 잘 들어가 있을 시
        let DESC02 = self.CharLitstwithVO.sorted{ $0.id > $1.id }
        
        self.chartList = DESC01
        
    }
    
    @IBOutlet weak var mainTableVw: UITableView!
    
    var chartList = [[String:Any]](){
        // chartList의 값이 변할 때, 테이블을 리로드 한다 !
        didSet{
            mainTableVw.reloadData()
        }
    }
    
    
    var CharLitstwithVO = [Chart](){
        // chartList의 값이 변할 때, 테이블을 리로드 한다 !
        didSet{
            mainTableVw.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // 테이블 뷰에 데이터및 델리게이트 연결
        mainTableVw.dataSource = self
        mainTableVw.delegate = self
        
        // 현재 뷰에 서치바 델리게이트 연결
        self.SearchBar.delegate = self
        
        // 현재 뷰에 키보드 델리게이트 연결
        self.keyoardDismiss.delegate = self
        
        // 키보드의 제스쳐에 따른 동작 추가
        self.view.addGestureRecognizer(keyoardDismiss)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        // 뷰가 보이기 전에 데이터를 받아오자
        fetchCarList(selectType)
    }
    
    // api 통신 하는 부분
    func fetchCarList(_ type:ChartType){
        
        guard let url = URL(string:"http://localhost:3300/v1/chart/\(type.code)") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                
                return
            }
            
            guard let resultData = data else { return }
            do {
                guard let result = try JSONSerialization.jsonObject(with: resultData, options: .fragmentsAllowed) as? [String:Any] else { return }
                
                guard let charListe = result["chartList"] as? [[String:Any]] else { return }
                
                DispatchQueue.main.async {
                    
                    
                    // 파싱을 안하고 받아온 chartList 고대로 넘겨주기
                    self.chartList = charListe
                    
                    // map을 사용해서 정해진 초기화 함수로 파싱을 해서 리스트에 차트 객체로 넣어주기
                    self.CharLitstwithVO = charListe.map{ Chart($0) }
                   
                }
                
                print(result)
                
            } catch {
                print(error.localizedDescription)
                
            }
            
        }
        task.resume()
    }
    
}

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.chartList.count
    }
    
    func tableView(_ mainTableVw: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = mainTableVw.dequeueReusableCell(withIdentifier: "TableVwCell") as? TableVwCell else { return UITableViewCell() }
        
        let val = self.chartList[indexPath.row]
        
        cell.idLB.text = String(val["id"] as? Int ?? 0)
        cell.SingerLB.text = val["singer"] as? String ?? ""
        cell.titleLB.text = val["title"] as? String ?? ""
        cell.imgVw.image = UIImage(named: (val["imageUrl"] as? String ?? "").components(separatedBy: ".")[0])
        
        return cell
    }
    
    
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storybrd = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storybrd.instantiateViewController(withIdentifier: "DetailVC") as? DetailVC else { return }
        
        let val = CharLitstwithVO[indexPath.row]
        
        vc.ID = val.id
        
        navigationController?.pushViewController(vc, animated: true)
        present(vc, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
               
        guard indexPath.row == (self.chartList.count - 1) else {
           
            return
        }
    
    }
    
}

extension ViewController: UISearchBarDelegate{
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
        
        if let keyword = self.SearchBar.text {
            
            let aa = self.chartList.filter{ ( $0["title"] as? String ?? "" ).contains(keyword) }
            
            let bb = self.CharLitstwithVO.filter{ $0.title.contains(keyword) }
            
            self.chartList = aa
            
        }
    }
}

extension ViewController: UIGestureRecognizerDelegate{
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        
        // 터치로 들어온 뷰가 요놈이면-> 즉 segue나 검색바를 누르면 keyboard가 없어지지는 않지만, 나머지 부분을 누르면 없어지게 설정하기
        if (touch.view?.isDescendant(of: SearchBar) == true){
            print("서치바가 터치되었다.")
            return false
        } else {
            view.endEditing(true)
            return true
        }
    }
    
}
