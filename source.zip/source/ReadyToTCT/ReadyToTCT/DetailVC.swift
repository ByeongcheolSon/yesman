//
//  DetailVC.swift
//  ReadyToTCT
//
//  Created by EMS on 2022/05/23.
//

import Foundation
import UIKit

class DetailVC: UIViewController {
    
    @IBOutlet weak var MainTitleLB: UILabel!
    @IBOutlet weak var MainSingerLB: UILabel!

    @IBOutlet weak var SingerLB: UILabel!
    
    @IBOutlet weak var MelodizerLB: UILabel!
    @IBOutlet weak var GenreLB: UILabel!
    
    var ID:Int = 0
    
    var chartVO:Detail?{
        didSet{
            MainTitleLB.text = chartVO?.title as? String ?? ""
            MainSingerLB.text = chartVO?.singer as? String ?? ""
            SingerLB.text = chartVO?.singer as? String ?? ""
            MelodizerLB.text = chartVO?.melodizer as? String ?? ""
            GenreLB.text = chartVO?.genre as? String ?? ""
        }
    }
    
    struct Detail {
        var id:Int
        var title:String
        var singer:String
        var melodizer:String
        var lyricist:String
        var genre:String
        
        init(data dic:[String:Any]) {
            id = dic["id"] as? Int ?? 0
            title = dic["title"] as? String ?? ""
            singer = dic["singer"] as? String ?? ""
            melodizer = dic["melodizer"] as? String ?? ""
            lyricist = dic["lyricist"] as? String ?? ""
            genre = dic["genre"] as? String ?? ""
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchCarList(songId: self.ID)
        
        
    }
    
    func fetchCarList(songId num:Int){
        
        guard let url = URL(string:"http://localhost:3300/v1/chart/detail/\(num)") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                
                return
            }
            
            guard let resultData = data else { return }
            do {
                guard let result = try JSONSerialization.jsonObject(with: resultData, options: .fragmentsAllowed) as? [String:Any] else { return }
                
                guard let chart = result["chart"] as? [String:Any] else { return }
                
                DispatchQueue.main.async {
                    
//
//                    // 파싱을 안하고 받아온 chartList 고대로 넘겨주기
//                    self.chartList = charListe
//
//                    // map을 사용해서 정해진 초기화 함수로 파싱을 해서 리스트에 차트 객체로 넣어주기
                    self.chartVO = Detail(data: chart)
//
                }
                
                print(result)
                
            } catch {
                print(error.localizedDescription)
                
            }
            
        }
        task.resume()
    }
    
    
    
}
