//
//  DetailVc.swift
//  CartApp
//
//  Created by EMS on 2022/05/23.
//

import Foundation
import UIKit

struct Item {
    var id, price:Int
    var title, imageFile, company, model:String
    
    var imageName:String{
        guard imageFile.contains(".") else { return imageFile }
        return imageFile.components(separatedBy: ".")[0]
    }
    
    
    init(_ dic:[String:Any]) {
        
        id = dic["id"] as? Int ?? 0
        price = dic["price"] as? Int ?? 0
        title = dic["title"] as? String ?? ""
        imageFile = dic["imageFile"] as? String ?? ""
        company = dic["company"] as? String ?? ""
        model = dic["model"] as? String ?? ""
      
        
    }
}

class DetailVc: UIViewController {
    
    @IBOutlet weak var titleLB: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var priceLB: UILabel!
    
    @IBOutlet weak var modelLB: UILabel!
    @IBOutlet weak var companyLB: UILabel!
    
    var id = 0
    
    var itemVO:Item?{
        didSet{
            titleLB.text = itemVO?.title as? String ?? ""
            imageView.image = UIImage(named: (itemVO?.imageName as? String ?? ""))
            priceLB.text = priceFomatter(itemVO?.price as? Int ?? 0)
            modelLB.text = itemVO?.model as? String ?? ""
            companyLB.text = itemVO?.company as? String ?? ""
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the vi
        fetchCarList(id)

    }
    
    
    
    func priceFomatter(_ price: Int) -> String {
        
        var formatter:NumberFormatter = NumberFormatter()
        formatter.numberStyle = .decimal
//        formatter.groupingSeparator = ","
        var commoaString = formatter.string(from: price as? NSNumber ?? 0)!
        return commoaString

        
    }
    
    func fetchCarList(_ id:Int){
        
        guard let url = URL(string:"http://localhost:3300/v1/item/\(id)") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                
                return
            }
            
            guard let resultData = data else { return }
            do {
                guard let result = try JSONSerialization.jsonObject(with: resultData, options: .fragmentsAllowed) as? [String:Any] else { return }
                
                guard let list = result["item"] as? [String:Any] else { return }
                
                DispatchQueue.main.async {
                          
                    self.itemVO = Item(list)
                   
                }
                
                print(result)
                
            } catch {
                print(error.localizedDescription)
                
            }
            
        }
        task.resume()
    }
    
}
