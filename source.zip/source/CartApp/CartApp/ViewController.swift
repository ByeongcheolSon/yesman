//
//  ViewController.swift
//  CartApp
//
//  Created by EMS on 2022/05/23.
//

import UIKit

struct Cart {
    var id, price:Int
    var title, imageFile:String
    
    var imageName:String{
        guard imageFile.contains(".") else { return imageFile }
        return imageFile.components(separatedBy: ".")[0]
    }
    
    
    init(_ dic:[String:Any]) {
        
        id = dic["id"] as? Int ?? 0
        price = dic["price"] as? Int ?? 0
        title = dic["title"] as? String ?? ""
        imageFile = dic["imageFile"] as? String ?? ""
        
    }
}

class ViewController: UIViewController {
    
    @IBOutlet weak var tableVw: UITableView!
    
    @IBOutlet weak var realPriceLB: UILabel!
    @IBOutlet weak var deliveryPriceLB: UILabel!
    @IBOutlet weak var totalPriceLB: UILabel!
    var CartList = [Cart](){
        didSet{
            
            var total = 0
            for item in CartList {
                
                total += item.price
            }
            totalPriceLB.text = priceFomatter(total)
            
            if total < 50000 {
                deliveryPriceLB.text = priceFomatter(3000)
                realPriceLB.text = "(\(CartList.count)개) \(priceFomatter(total+3000))"
            }else{
                deliveryPriceLB.text = priceFomatter(0)
                realPriceLB.text = "(\(CartList.count)개) \(priceFomatter(total))"
                
            }
            
            
            
            tableVw.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableVw.delegate = self
        tableVw.dataSource = self
        
        
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        fetchCarList()
        
    }
    
    func fetchCarList(){
        
        guard let url = URL(string:"http://localhost:3300/v1/cartList/") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                
                return
            }
            
            guard let resultData = data else { return }
            do {
                guard let result = try JSONSerialization.jsonObject(with: resultData, options: .fragmentsAllowed) as? [String:Any] else { return }
                
                guard let list = result["cartList"] as? [[String:Any]] else { return }
                
                DispatchQueue.main.async {
                    
      
                    self.CartList = list.map{ Cart($0) }
                   
                }
                
                print(result)
                
            } catch {
                print(error.localizedDescription)
                
            }
            
        }
        task.resume()
    }
    


}

extension ViewController:UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let cell = tableVw.cellForRow(at: indexPath) else { return }
        cell.isSelected = false
        
        let storybrd = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storybrd.instantiateViewController(withIdentifier: "DetailVc") as? DetailVc else { return }
        
        let val = CartList[indexPath.row]
        
     
        vc.id = val.id
        
        navigationController?.pushViewController(vc, animated: true)
//        present(vc, animated: true, completion: nil)

    }
}

extension ViewController:UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CartList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableVw.dequeueReusableCell(withIdentifier: "TableVwCell") as? TableVwCell else { return UITableViewCell() }
        
        let val = self.CartList[indexPath.row]
        
        cell.titleLB.text = val.title
        cell.imageVw.image = UIImage(named: val.imageName)
        cell.priceLB.text = priceFomatter(val.price)
        
        
        
        return cell
    }
    
    func priceFomatter(_ price: Int) -> String {
        
        var formatter:NumberFormatter = NumberFormatter()
        formatter.numberStyle = .decimal
//        formatter.groupingSeparator = ","
        var commoaString = formatter.string(from: price as? NSNumber ?? 0)!
        return commoaString

        
    }
}

