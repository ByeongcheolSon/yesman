//
//  TableVwCell.swift
//  CartApp
//
//  Created by EMS on 2022/05/23.
//

import Foundation
import UIKit

class TableVwCell:UITableViewCell{
    
    
    @IBOutlet weak var imageVw: UIImageView!
    
    @IBOutlet weak var titleLB: UILabel!
    
    @IBOutlet weak var priceLB: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

